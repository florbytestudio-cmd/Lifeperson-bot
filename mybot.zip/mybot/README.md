# MyBot — Asistente Personal FlorByte

Bot de Telegram personal con 6 categorías: Banco, FlorByte, Membresías, Tareas, Proyectos y Notas.

---

## Setup en 4 pasos

### Paso 1 — Crear el bot en Telegram (2 min)
1. Abre Telegram → busca **@BotFather**
2. Escribe `/newbot`
3. Dale un nombre: `Mi Asistente` y un username: `miasistente_bot`
4. Copia el **token** que te da (ej: `7123456789:AAF...`)

### Paso 2 — Obtener tu User ID
1. Busca **@userinfobot** en Telegram
2. Escribe `/start`
3. Copia tu **Id** numérico (ej: `123456789`)

### Paso 3 — Supabase
1. https://supabase.com → nuevo proyecto (gratis)
2. SQL Editor → pega `supabase/schema.sql` → Run
3. Settings → API → copia URL y anon key

### Paso 4 — Deploy en Railway
1. Sube el proyecto a GitHub
2. https://railway.app → New Project → Deploy from GitHub
3. Variables de entorno:
   ```
   TELEGRAM_TOKEN=tu_token
   TELEGRAM_USER_ID=tu_user_id
   SUPABASE_URL=https://...supabase.co
   SUPABASE_ANON_KEY=eyJ...
   OPENAI_API_KEY=sk-...
   ```
4. Start Command: `npm install && npm start`

---

## Uso diario

### Comandos
- `/start` — menú principal + activa recordatorios
- `/menu` — volver al menú en cualquier momento

### Banco
- Texto: `250 gasolina` después de seleccionar tarjeta
- Foto: manda foto del ticket → detecta automáticamente la tarjeta o te pregunta

### FlorByte
- Audio: manda nota de voz con los datos del prospecto → Whisper transcribe → GPT extrae nombre, red, industria

### Membresías
- Formato: `YouTube Music 99 MXN dia15`

### Tareas
- Selecciona prioridad con botones → escribe el título

### Proyectos
- El bot te va preguntando nombre, descripción, presupuesto y fecha de entrega

### Notas
- Texto o audio → se guarda y es buscable

### Nueva categoría
- Escribe `🏥 Salud` o simplemente `Gym`

---

## Recordatorios automáticos (9am México)
- Membresías que se cobran en 3 días
- Resumen de tareas de alta prioridad
