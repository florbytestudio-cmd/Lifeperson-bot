import cron from 'node-cron'
import { getUpcomingMemberships, getTasks } from '../db/index.js'
import dayjs from 'dayjs'

export function startScheduler(bot, chatId) {
  // Recordatorio membresías — cada día a las 9am México
  cron.schedule('0 15 * * *', async () => {
    try {
      const upcoming = await getUpcomingMemberships(3)
      for (const m of upcoming) {
        await bot.sendMessage(chatId,
          `🔔 *Recordatorio de membresía*\n\n📦 *${m.name}* se cobra en 3 días\n💰 $${m.amount} ${m.currency}`,
          { parse_mode: 'Markdown' }
        )
      }
    } catch (err) {
      console.error('[scheduler] Error membresías:', err.message)
    }
  }, { timezone: 'UTC' })

  // Resumen diario de tareas — 9am México
  cron.schedule('0 15 * * *', async () => {
    try {
      const tasks = await getTasks(false)
      const altas = tasks.filter(t => t.priority === 'alta')
      if (altas.length === 0) return

      let text = `☀️ *Buenos días — tareas de alta prioridad hoy:*\n\n`
      altas.slice(0, 5).forEach((t, i) => {
        text += `🔴 ${i + 1}. ${t.title}\n`
      })
      if (tasks.length > altas.length) {
        text += `\n_+${tasks.length - altas.length} tarea(s) de menor prioridad_`
      }
      await bot.sendMessage(chatId, text, { parse_mode: 'Markdown' })
    } catch (err) {
      console.error('[scheduler] Error tareas:', err.message)
    }
  }, { timezone: 'UTC' })

  console.log('[scheduler] Recordatorios activos')
}
