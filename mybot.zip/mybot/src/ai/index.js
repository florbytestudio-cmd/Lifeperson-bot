import OpenAI from 'openai'
import fs from 'fs'
import axios from 'axios'
import FormData from 'form-data'
import path from 'path'
import os from 'os'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

// ── Transcribir audio con Whisper ───────────────────────────────────────────
export async function transcribeAudio(fileUrl, botToken) {
  const tmpPath = path.join(os.tmpdir(), `audio_${Date.now()}.ogg`)
  const writer = fs.createWriteStream(tmpPath)
  const response = await axios({ url: fileUrl, method: 'GET', responseType: 'stream' })
  await new Promise((res, rej) => { response.data.pipe(writer); writer.on('finish', res); writer.on('error', rej) })

  const transcript = await openai.audio.transcriptions.create({
    file: fs.createReadStream(tmpPath),
    model: 'whisper-1',
    language: 'es',
  })
  fs.unlinkSync(tmpPath)
  return transcript.text
}

// ── Extraer datos de prospecto de transcripción ─────────────────────────────
export async function extractProspectData(transcript) {
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{
      role: 'user',
      content: `Del siguiente texto, extrae información de un prospecto de negocios.
Responde SOLO en JSON con esta estructura exacta:
{
  "name": "nombre del contacto o negocio",
  "business": "nombre del negocio si es diferente",
  "platform": "instagram|facebook|otro",
  "profile_url": "url del perfil si se menciona o null",
  "industry": "restaurante|ropa|belleza|inmobiliaria|otro",
  "notes": "observaciones relevantes del audio"
}

Texto: "${transcript}"`
    }],
    max_tokens: 300,
    response_format: { type: 'json_object' },
  })
  return JSON.parse(res.choices[0].message.content)
}

// ── Extraer monto de ticket con Vision ─────────────────────────────────────
export async function extractTicketData(imageUrl) {
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{
      role: 'user',
      content: [
        {
          type: 'image_url',
          image_url: { url: imageUrl, detail: 'low' }
        },
        {
          type: 'text',
          text: `Analiza este ticket/comprobante y extrae los datos.
Responde SOLO en JSON:
{
  "amount": 123.45,
  "description": "descripción corta del gasto",
  "bank": "banco si aparece en el ticket o null",
  "card_last4": "últimos 4 dígitos de tarjeta o null",
  "date": "fecha en formato YYYY-MM-DD o null"
}`
        }
      ]
    }],
    max_tokens: 200,
    response_format: { type: 'json_object' },
  })
  return JSON.parse(res.choices[0].message.content)
}

// ── Respuesta general de IA ─────────────────────────────────────────────────
export async function aiReply(userMessage, context = '') {
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [
      {
        role: 'system',
        content: `Eres el asistente personal de FlorByte Studio. Hablas en español mexicano, informal y directo. 
Ayudas con finanzas personales, prospectos de negocio, tareas y notas.
${context ? `Contexto actual: ${context}` : ''}
Responde de forma breve y útil, máximo 3 oraciones.`
      },
      { role: 'user', content: userMessage }
    ],
    max_tokens: 200,
  })
  return res.choices[0].message.content.trim()
}

// ── Buscar en notas con IA ──────────────────────────────────────────────────
export async function summarizeSearchResults(query, notes) {
  if (!notes.length) return `No encontré notas sobre "${query}".`
  const notesText = notes.map((n, i) => `${i+1}. [${n.created_at?.slice(0,10)}] ${n.content}`).join('\n')
  const res = await openai.chat.completions.create({
    model: 'gpt-4o-mini',
    messages: [{
      role: 'user',
      content: `El usuario busca: "${query}"\n\nNotas encontradas:\n${notesText}\n\nResume los resultados más relevantes en 2-3 líneas en español mexicano.`
    }],
    max_tokens: 150,
  })
  return res.choices[0].message.content.trim()
}
